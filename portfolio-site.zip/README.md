# Portfolio Website — SoftNexis Internship Task 1

## Overview
A minimal, responsive 3-page personal portfolio website built for Task 1 of the SoftNexis Web Development Internship.

## Structure
```
portfolio-site/
├── index.html
├── about.html
├── contact.html
├── styles/main.css
└── README.md
```

## Features
- 3 responsive pages (Home, About, Contact)
- Consistent navigation bar
- Flexbox/Grid-based layout
- Media queries for mobile & desktop
- Hover effects and clean white theme
- Semantic HTML5 structure

## Deployment
### GitHub Pages
1. Push code to GitHub repository.
2. Go to Settings → Pages.
3. Set branch to `main` and folder to `/ (root)`.
4. Visit `https://username.github.io/repo-name/`.

### Netlify
Drag and drop the folder into [Netlify Drop](https://app.netlify.com/drop) or connect via GitHub.

## Author
**Sudip Bagdi**  
Software Developer — B.E. Information Technology, UIT
